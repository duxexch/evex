#!/bin/bash
# سكريبت تشغيل البوت مع جميع المميزات

echo "🚀 بدء تشغيل بوت LangSense..."
echo ""
echo "✅ التحقق من البيئة..."

# التحقق من Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 غير مثبت"
    exit 1
fi

echo "✅ Python متاح"

# التحقق من الملفات الأساسية
if [ ! -f "main.py" ]; then
    echo "❌ ملف main.py غير موجود"
    exit 1
fi

echo "✅ الملفات الأساسية موجودة"

# التحقق من .env
if [ ! -f ".env" ]; then
    echo "⚠️ ملف .env غير موجود - سيتم استخدام .env.example"
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo "⚠️ يرجى تحديث ملف .env بالبيانات الصحيحة"
    fi
fi

echo "✅ ملف البيئة جاهز"

# تشغيل البوت
echo ""
echo "🤖 تشغيل البوت..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

python3 main.py

# في حالة توقف البوت
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "⛔ البوت توقف"
